Array4d v(-0.5,2,0,-7);
cout << v.erf() << endl;
