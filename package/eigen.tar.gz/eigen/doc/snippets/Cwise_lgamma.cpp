Array4d v(0.5,10,0,-1);
cout << v.lgamma() << endl;